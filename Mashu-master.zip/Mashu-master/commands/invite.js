module.exports = {
  exec: (client, message, content, args) => {
    message.send("Please use this [LINK](https://discordapp.com/oauth2/authorize?client_id=259634602199482368&scope=bot) to invite me to your server, senpai");
  }
}
