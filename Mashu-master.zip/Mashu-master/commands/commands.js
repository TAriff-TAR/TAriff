module.exports = {
  exec: (client, message, content, args) => {
    message.send("If you need my command list, please read this [LINK](https://github.com/aister/Mashu/blob/master/README.md), senpai");
  }
}
