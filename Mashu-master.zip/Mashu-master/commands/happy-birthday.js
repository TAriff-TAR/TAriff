module.exports = {
  exec: (client, message, content, args) => {
    message.send("ehehe, thanks " + message.author + "-[s]!", "smile");
  }
}
