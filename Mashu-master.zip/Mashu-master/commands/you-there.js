module.exports = {
  exec: (client, message, content, args) => {
    message.send("Yes senpai. I'm here.");
  }
}