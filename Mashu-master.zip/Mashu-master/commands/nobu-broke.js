module.exports = {
  exec: (client, message, content, args) => {
    message.send("it's all R~'s fault!", "smile");
  }
}
